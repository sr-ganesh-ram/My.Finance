﻿windows.logs = {

    Warn: function (msg) {
        console.warn(msg);
    },

    Error: function (err) {
        console.error(err);
    },

    Log: function (msg) {
        console.log(msg);
    },

}